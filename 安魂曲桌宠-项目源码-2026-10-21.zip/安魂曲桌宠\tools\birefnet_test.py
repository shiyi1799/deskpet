import os
import sys

import numpy as np
from PIL import Image
from rembg import new_session, remove
from scipy import ndimage

sys.stdout.reconfigure(encoding="utf-8")

OUT = "tmp"
os.makedirs(OUT, exist_ok=True)

ref = Image.open("assets/reference/reference.jpg").convert("RGB")
session = new_session("birefnet-general-lite")

crops = {
    "wide": (70, 85, 360, 740),
    "tight": (100, 100, 350, 735),
    "full": (0, 0, 720, 981),
}

for name, box in crops.items():
    crop = ref.crop(box)
    cut = remove(crop, session=session, post_process_mask=False)
    cut.save(f"{OUT}/biref_{name}.png")

    rgba = np.array(cut)
    alpha = rgba[:, :, 3]
    solid = (alpha > 128).astype(np.uint8)
    labels, count = ndimage.label(solid)
    sizes = ndimage.sum(solid, labels, range(1, count + 1))
    order = np.argsort(sizes)[::-1]
    print(f"[{name}] crop={crop.size} components={count}")
    for idx in order[:8]:
        lid = idx + 1
        ys, xs = np.where(labels == lid)
        print(
            f"  id={lid} area={int(sizes[idx])} bbox=({xs.min()},{ys.min()},{xs.max()},{ys.max()})"
        )

    # checker + dark previews
    for bgname, bgcolor in (("checker", None), ("dark", (24, 26, 34))):
        if bgcolor is None:
            tile = 12
            bg = Image.new("RGB", crop.size)
            px = bg.load()
            for y in range(crop.size[1]):
                for x in range(crop.size[0]):
                    v = 200 if ((x // tile) + (y // tile)) % 2 == 0 else 155
                    px[x, y] = (v, v, v)
        else:
            bg = Image.new("RGB", crop.size, bgcolor)
        bg.paste(cut, (0, 0), cut)
        bg.save(f"{OUT}/biref_{name}_{bgname}.png")
