(() => {
  'use strict';

  const api = window.petAPI;

  const sprite = document.getElementById('sprite');
  const motion = document.getElementById('motion');
  const fx = document.getElementById('fx');

  const PALETTE = ['#37A4FF', '#244DFF', '#7C6BCE', '#C4AA5B', '#E9EEF8', '#D94C5C'];

  const state = {
    mode: 'idle',
    paused: false,
    dragging: false,
    mask: null,
    ignoreMouse: false,
    dock: null,
    lastPointer: { x: -1, y: -1 },
  };

  let reactTimer = null;
  let ambientTimer = null;
  let hitRaf = 0;
  let pending = null;
  let drag = null;

  document.body.dataset.state = 'idle';

  const rand = (min, max) => min + Math.random() * (max - min);

  function setMode(mode) {
    if (state.mode === mode) return;
    state.mode = mode;
    motion.classList.remove('reacting', 'dragging');
    if (mode !== 'idle') {
      motion.classList.add(mode);
    }
    document.body.dataset.state = mode;
  }

  function clearReactTimer() {
    clearTimeout(reactTimer);
    reactTimer = null;
  }

  function react() {
    if (state.paused) return;
    clearReactTimer();
    setMode('reacting');
    spawnBurst();
    reactTimer = setTimeout(() => {
      reactTimer = null;
      if (state.paused || state.dragging) return;
      setMode('idle');
    }, 720);
  }

  function pause() {
    state.paused = true;
    clearReactTimer();
    clearTimeout(ambientTimer);
    ambientTimer = null;
    pending = null;
    drag = null;
    state.dragging = false;
    document.body.classList.remove('dragging');
    setMode('idle');
  }

  function resume() {
    if (!state.paused) return;
    state.paused = false;
    setMode('idle');
    armMousePassthrough();
    scheduleAmbient();
  }

  api.onPaused((paused) => {
    if (paused) {
      pause();
    } else {
      resume();
    }
  });

  api.onDocked((side) => {
    state.dock = side;
    document.body.classList.toggle('dock-left', side === 'left');
    document.body.classList.toggle('dock-right', side === 'right');
    updateDockShift();
  });

  function updateDockShift() {
    const free = Math.max(0, Math.round((window.innerWidth - sprite.offsetWidth) / 2));
    const shift = state.dock === 'left' ? -free : state.dock === 'right' ? free : 0;
    document.body.style.setProperty('--dock-shift', `${shift}px`);
  }

  api.onRecall(() => {
    clearReactTimer();
    state.dragging = false;
    pending = null;
    drag = null;
    document.body.classList.remove('dragging');
    setMode('idle');
    armMousePassthrough();
  });

  function onPointerDown(event) {
    if (event.button !== 0 || state.paused) return;
    event.preventDefault();

    clearReactTimer();
    pending = {
      pointerId: event.pointerId,
      startX: event.screenX,
      startY: event.screenY,
      startedAt: performance.now(),
    };
    setMode('idle');
    setIgnoreMouse(false);

    try {
      sprite.setPointerCapture(event.pointerId);
    } catch {
      /* pointer capture is best-effort */
    }
  }

  function startDrag(pointerId) {
    drag = { pointerId, startedAt: pending.startedAt };
    pending = null;
    state.dragging = true;
    document.body.classList.add('dragging');
    setMode('dragging');
    setIgnoreMouse(false);
    api.dragStart();
    api.dragMove();
  }

  function onPointerMove(event) {
    if (drag) {
      if (event.pointerId === drag.pointerId) {
        api.dragMove();
      }
      return;
    }
    if (!pending || event.pointerId !== pending.pointerId) return;

    const moved = Math.hypot(event.screenX - pending.startX, event.screenY - pending.startY);
    if (moved >= 4) {
      startDrag(pending.pointerId);
    }
  }

  function onPointerUp(event) {
    if (!pending && !drag) return;
    if (pending && event.pointerId !== pending.pointerId && !drag) return;
    if (drag && event.pointerId !== drag.pointerId) return;

    const activeDrag = drag;
    const held = pending;

    try {
      sprite.releasePointerCapture(event.pointerId);
    } catch {
      /* pointer capture is best-effort */
    }

    drag = null;
    pending = null;
    state.dragging = false;
    document.body.classList.remove('dragging');

    if (activeDrag) {
      api.dragEnd();
      setMode('idle');
      return;
    }

    if (!held) return;
    const isClick =
      event.type === 'pointerup' && performance.now() - held.startedAt < 600;

    if (isClick) {
      react();
    } else {
      setMode('idle');
    }
  }

  sprite.addEventListener('pointerdown', onPointerDown);
  sprite.addEventListener('pointermove', onPointerMove);
  sprite.addEventListener('pointerup', onPointerUp);
  sprite.addEventListener('pointercancel', onPointerUp);
  sprite.addEventListener('dragstart', (event) => event.preventDefault());

  function setIgnoreMouse(ignore) {
    if (state.ignoreMouse === ignore) return;
    state.ignoreMouse = ignore;
    api.setIgnoreMouse(ignore);
  }

  function armMousePassthrough() {
    state.ignoreMouse = true;
    api.setIgnoreMouse(true);
    if (state.lastPointer.x >= 0 && state.lastPointer.y >= 0) {
      updateHitTest(state.lastPointer.x, state.lastPointer.y);
    }
  }

  function updateHitTest(x, y) {
    if (!state.mask || x < 0 || y < 0) return;
    const rect = sprite.getBoundingClientRect();
    let over = false;

    if (
      rect.width > 0 &&
      rect.height > 0 &&
      x >= rect.left &&
      x <= rect.right &&
      y >= rect.top &&
      y <= rect.bottom
    ) {
      const u = (x - rect.left) / rect.width;
      const v = (y - rect.top) / rect.height;
      const mx = Math.min(state.mask.w - 1, Math.max(0, Math.floor(u * state.mask.w)));
      const my = Math.min(state.mask.h - 1, Math.max(0, Math.floor(v * state.mask.h)));
      over = state.mask.data[my * state.mask.w + mx] > 22;
    }

    setIgnoreMouse(!over);
  }

  function onDocumentMouseMove(event) {
    state.lastPointer.x = event.clientX;
    state.lastPointer.y = event.clientY;

    if (hitRaf) return;
    hitRaf = requestAnimationFrame(() => {
      hitRaf = 0;
      if (state.dragging) {
        setIgnoreMouse(false);
        return;
      }
      updateHitTest(state.lastPointer.x, state.lastPointer.y);
    });
  }

  document.addEventListener('mousemove', onDocumentMouseMove);
  document.addEventListener('mouseleave', () => {
    if (!state.dragging) {
      setIgnoreMouse(true);
    }
  });
  window.addEventListener('contextmenu', (event) => event.preventDefault());

  function buildMask() {
    const naturalWidth = sprite.naturalWidth;
    const naturalHeight = sprite.naturalHeight;
    if (!naturalWidth || !naturalHeight) return;

    const width = Math.min(120, naturalWidth);
    const height = Math.max(1, Math.round(naturalHeight * (width / naturalWidth)));
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const context = canvas.getContext('2d', { willReadFrequently: true });
    context.drawImage(sprite, 0, 0, width, height);
    const pixels = context.getImageData(0, 0, width, height).data;
    const mask = new Uint8Array(width * height);

    for (let i = 0; i < mask.length; i += 1) {
      mask[i] = pixels[i * 4 + 3];
    }

    state.mask = { w: width, h: height, data: mask };
    updateDockShift();
    armMousePassthrough();
  }

  if (sprite.complete && sprite.naturalWidth) {
    buildMask();
  } else {
    sprite.addEventListener('load', buildMask, { once: true });
  }

  function spawnBurst() {
    const count = 16;

    for (let i = 0; i < count; i += 1) {
      const particle = document.createElement('div');
      const typeRoll = Math.random();
      const type = typeRoll < 0.55 ? 'petal' : typeRoll < 0.85 ? 'star' : 'spark';
      particle.className = `particle ${type}`;

      const angle = rand(0, Math.PI * 2);
      const distance = rand(32, 72);
      const dx = Math.cos(angle) * distance;
      const dy = Math.sin(angle) * distance - rand(18, 46);
      const size =
        type === 'petal' ? rand(6, 10) : type === 'star' ? rand(5, 9) : rand(3, 5);

      particle.style.setProperty('--dx', `${dx.toFixed(1)}px`);
      particle.style.setProperty('--dy', `${dy.toFixed(1)}px`);
      particle.style.setProperty('--rot', `${Math.round(rand(-260, 260))}deg`);
      particle.style.setProperty('--size', `${size.toFixed(1)}px`);
      particle.style.setProperty('--color', PALETTE[Math.floor(Math.random() * PALETTE.length)]);
      particle.style.setProperty('--dur', `${Math.round(rand(680, 1080))}ms`);
      particle.style.setProperty('--delay', `${Math.round(rand(0, 90))}ms`);
      particle.style.left = `${(44 + Math.random() * 12).toFixed(1)}%`;
      particle.style.top = `${(34 + Math.random() * 20).toFixed(1)}%`;

      fx.appendChild(particle);
      setTimeout(() => particle.remove(), 1350);
    }
  }

  function spawnAmbientPetal() {
    const petal = document.createElement('div');
    petal.className = 'ambient';
    petal.style.setProperty('--size', `${rand(4, 8).toFixed(1)}px`);
    petal.style.setProperty('--dx', `${rand(-36, 36).toFixed(1)}px`);
    petal.style.setProperty('--dy', `${(-rand(100, 210)).toFixed(1)}px`);
    petal.style.setProperty('--rot', `${Math.round(rand(-200, 200))}deg`);
    petal.style.setProperty('--dur', `${Math.round(rand(4200, 7000))}ms`);
    petal.style.setProperty('--peak', rand(0.28, 0.5).toFixed(2));
    petal.style.setProperty('--color', PALETTE[Math.floor(Math.random() * 3)]);
    petal.style.left = `${rand(30, 70).toFixed(1)}%`;
    petal.style.top = `${rand(62, 88).toFixed(1)}%`;

    fx.appendChild(petal);
    setTimeout(() => petal.remove(), 7600);
  }

  function scheduleAmbient() {
    clearTimeout(ambientTimer);
    ambientTimer = null;
    if (state.paused) return;

    ambientTimer = setTimeout(() => {
      ambientTimer = null;
      if (!state.paused && !state.dragging) {
        spawnAmbientPetal();
      }
      scheduleAmbient();
    }, rand(2400, 5200));
  }

  scheduleAmbient();
})();
