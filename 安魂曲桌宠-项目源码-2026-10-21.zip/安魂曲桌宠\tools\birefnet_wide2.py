import os
import sys

import numpy as np
from PIL import Image
from rembg import new_session

sys.stdout.reconfigure(encoding="utf-8")
OUT = "tmp"
ref = Image.open("assets/reference/reference.jpg").convert("RGB")
session = new_session("birefnet-general-lite")

box = (20, 70, 375, 770)
crop = ref.crop(box)
w, h = crop.size
side = max(w, h)
pl = (side - w) // 2
pr = side - w - pl
bg_color = crop.getpixel((w - 6, 6))
canvas = Image.new("RGB", (side, h), bg_color)
canvas.paste(crop, (pl, 0))

mask = session.predict(canvas)[0].crop((pl, 0, pl + w, h))
rgba = np.array(crop.convert("RGBA"))
rgba[:, :, 3] = np.array(mask)
cut = Image.fromarray(rgba, "RGBA")
cut.save(f"{OUT}/biref_wide2.png")
print("cut", cut.size, "alpha>128", int((np.array(mask) > 128).sum()))

for name, color in (("white", (245, 245, 245)), ("dark", (24, 26, 34))):
    bg = Image.new("RGB", cut.size, color)
    bg.paste(cut, (0, 0), cut)
    bg.resize((cut.width * 2, cut.height * 2), Image.LANCZOS).save(f"{OUT}/biref_wide2_{name}.png")
