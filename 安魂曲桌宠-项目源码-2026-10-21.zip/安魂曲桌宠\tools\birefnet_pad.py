import os
import sys

import numpy as np
from PIL import Image
from rembg import new_session

sys.stdout.reconfigure(encoding="utf-8")

OUT = "tmp"
os.makedirs(OUT, exist_ok=True)

ref = Image.open("assets/reference/reference.jpg").convert("RGB")
session = new_session("birefnet-general-lite")

box = (70, 85, 360, 740)
crop = ref.crop(box)
w, h = crop.size

# pad horizontally to a square, sampling background color from the top-right of the crop
side = max(w, h)
pad_left = (side - w) // 2
pad_right = side - w - pad_left
bg_color = crop.getpixel((w - 6, 6))
canvas = Image.new("RGB", (side, h), bg_color)
canvas.paste(crop, (pad_left, 0))

mask = session.predict(canvas)[0].crop((pad_left, 0, pad_left + w, h))
mask.save(f"{OUT}/biref_pad_mask.png")

rgba = np.array(crop.convert("RGBA"))
alpha = np.array(mask)
rgba[:, :, 3] = alpha
cut = Image.fromarray(rgba, "RGBA")
cut.save(f"{OUT}/biref_pad.png")

alpha_solid = (alpha > 128)
print("alpha>128 pixels:", int(alpha_solid.sum()), "of", w * h)

# previews
for bgname, color in (("dark", (24, 26, 34)), ("checker", None)):
    if color is None:
        tile = 12
        bg = Image.new("RGB", cut.size)
        px = bg.load()
        for y in range(h):
            for x in range(w):
                v = 200 if ((x // tile) + (y // tile)) % 2 == 0 else 155
                px[x, y] = (v, v, v)
    else:
        bg = Image.new("RGB", cut.size, color)
    bg.paste(cut, (0, 0), cut)
    bg.save(f"{OUT}/biref_pad_{bgname}.png")

# zoom alpha for comparison
region = alpha[60:200, 185:275]
Image.fromarray(region).convert("L").point(lambda v: min(255, v * 2)).resize(
    (region.shape[1] * 5, region.shape[0] * 5), Image.NEAREST
).save(f"{OUT}/alpha_hair_zoom_pad.png")
