from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage

ROOT = Path(__file__).resolve().parent.parent
REF = ROOT / 'assets' / 'reference' / 'reference.jpg'
TMP = ROOT / 'tmp'
TMP.mkdir(exist_ok=True)

CROP = (40, 88, 362, 736)
SEEDS = {
    'face': (195, 100),
    'chest': (185, 230),
    'skirt': (180, 330),
    'foot': (170, 600),
    'candelabra': (285, 330),
}


def checker(img, cell=14):
    w, h = img.size
    bg = Image.new('RGBA', (w, h), (238, 238, 242, 255))
    draw = ImageDraw.Draw(bg)
    for y in range(0, h, cell):
        for x in range(0, w, cell):
            if (x // cell + y // cell) % 2:
                draw.rectangle([x, y, x + cell - 1, y + cell - 1], fill=(205, 207, 214, 255))
    bg.alpha_composite(img)
    return bg


def dark_bg(img):
    w, h = img.size
    bg = Image.new('RGBA', (w, h), (22, 24, 33, 255))
    draw = ImageDraw.Draw(bg)
    for i in range(h):
        shade = int(18 + 14 * (i / max(1, h - 1)))
        draw.line([(0, i), (w, i)], fill=(shade, shade + 2, shade + 9, 255))
    bg.alpha_composite(img)
    return bg


def main():
    crop = Image.open(REF).convert('RGB').crop(CROP)
    crop.save(TMP / 'char_crop.png')
    print('crop size:', crop.size, flush=True)

    raw_path = TMP / 'char_cutout_raw.png'
    if raw_path.exists():
        cut = Image.open(raw_path).convert('RGBA')
        print('using existing raw cutout', flush=True)
    else:
        from rembg import new_session, remove

        print('loading model...', flush=True)
        session = new_session('isnet-anime')
        print('running cutout...', flush=True)
        cut = remove(crop, session=session).convert('RGBA')
        cut.save(raw_path)
        print('raw cutout saved', flush=True)

    checker(cut).resize((cut.width * 2, cut.height * 2), Image.LANCZOS).save(
        TMP / 'raw_checker.png'
    )
    dark_bg(cut).save(TMP / 'raw_dark.png')

    alpha = np.array(cut.getchannel('A'))
    mask = alpha > 24
    labels, count = ndimage.label(mask, structure=np.ones((3, 3), dtype=int))
    sizes = ndimage.sum(mask, labels, range(1, count + 1)).astype(np.int64)
    print('component count:', count, flush=True)

    ids = [i for i in range(1, count + 1) if sizes[i - 1] >= 200]
    ids.sort(key=lambda i: sizes[i - 1], reverse=True)

    for name, (sx, sy) in SEEDS.items():
        if 0 <= sy < labels.shape[0] and 0 <= sx < labels.shape[1]:
            print(f'seed {name} ({sx},{sy}) -> component {labels[sy, sx]}', flush=True)

    print('top components:', flush=True)
    for i in ids[:15]:
        ys, xs = np.where(labels == i)
        print(
            f'  id={i} area={sizes[i - 1]} bbox=({xs.min()},{ys.min()},{xs.max()},{ys.max()})',
            flush=True,
        )

    vis = Image.new('RGB', cut.size, (18, 19, 26))
    vis_draw = ImageDraw.Draw(vis)
    palette = [
        (55, 164, 255),
        (196, 170, 91),
        (217, 76, 92),
        (124, 107, 206),
        (90, 200, 160),
        (240, 240, 246),
        (170, 120, 80),
        (80, 190, 230),
    ]
    arr = np.array(vis)
    for rank, i in enumerate(ids[:15]):
        color = palette[rank % len(palette)]
        arr[labels == i] = color
        ys, xs = np.where(labels == i)
        vis_draw.rectangle(
            [xs.min(), ys.min(), xs.max(), ys.max()],
            outline=color,
        )
        vis_draw.text((xs.min() + 3, ys.min() + 3), f'{i}:{sizes[i - 1]}', fill=color)
        part = cut.crop((xs.min(), ys.min(), xs.max() + 1, ys.max() + 1))
        checker(part, cell=10).save(TMP / f'comp_{rank:02d}_{i}.png')
    Image.fromarray(arr).save(TMP / 'components.png')

    print('saved previews to tmp/', flush=True)


if __name__ == '__main__':
    main()
