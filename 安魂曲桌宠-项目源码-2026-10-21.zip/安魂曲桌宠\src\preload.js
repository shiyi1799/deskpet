const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('petAPI', {
  dragStart: () => ipcRenderer.send('pet:drag-start'),
  dragMove: () => ipcRenderer.send('pet:drag-move'),
  dragEnd: () => ipcRenderer.send('pet:drag-end'),
  setIgnoreMouse: (ignore) => ipcRenderer.send('pet:set-ignore-mouse', ignore),
  onPaused: (callback) => {
    ipcRenderer.on('pet:paused', (_event, paused) => callback(Boolean(paused)));
  },
  onDocked: (callback) => {
    ipcRenderer.on('pet:docked', (_event, side) => callback(side ?? null));
  },
  onRecall: (callback) => {
    ipcRenderer.on('pet:recall', () => callback());
  },
});
