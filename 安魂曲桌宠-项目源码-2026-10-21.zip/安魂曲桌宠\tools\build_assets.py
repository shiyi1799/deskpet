import os

import numpy as np
from PIL import Image, ImageDraw, ImageFilter
from scipy import ndimage

OUT = "assets/pet"
os.makedirs(OUT, exist_ok=True)
os.makedirs("assets/tray", exist_ok=True)

cut = Image.open("tmp/biref_wide2.png").convert("RGBA")
rgba = np.array(cut)
alpha = rgba[:, :, 3]

solid = alpha > 100
solid = ndimage.binary_closing(solid, structure=np.ones((3, 3)), iterations=1)
labels, count = ndimage.label(solid)
sizes = ndimage.sum(solid, labels, range(1, count + 1))
main_id = int(np.argmax(sizes)) + 1
main = labels == main_id
near = ndimage.binary_dilation(main, iterations=2)
clean_alpha = np.where(near, alpha, 0)
clean_alpha = np.where(clean_alpha < 24, 0, clean_alpha)

rgba[:, :, 3] = clean_alpha.astype(np.uint8)
cut = Image.fromarray(rgba, "RGBA")

ys, xs = np.where(clean_alpha > 0)
pad = 6
bbox = (
    max(0, xs.min() - pad),
    max(0, ys.min() - pad),
    min(cut.width, xs.max() + 1 + pad),
    min(cut.height, ys.max() + 1 + pad),
)
pet = cut.crop(bbox)
pet.save(f"{OUT}/pet.png")
print("pet size:", pet.size, "bbox:", bbox)

# preview on dark and white
for name, color in (("dark", (24, 26, 34)), ("white", (245, 245, 245))):
    bg = Image.new("RGB", pet.size, color)
    bg.paste(pet, (0, 0), pet)
    bg.resize((pet.width * 2, pet.height * 2), Image.LANCZOS).save(f"tmp/pet_{name}.png")

# tray badge from the head area of the cleaned pet
head = pet.crop((90, 0, 280, 160))


def badge(size):
    scale = 8
    s = size * scale
    yy, xx = np.mgrid[0:s, 0:s]
    cx = cy = (s - 1) / 2
    dist = np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2) / (s / 2)
    t = np.clip(dist, 0, 1)[..., None]
    inner = np.array([52, 66, 104], dtype=np.float32)
    outer = np.array([13, 17, 28], dtype=np.float32)
    grad = (inner * (1 - t) + outer * t).astype(np.uint8)
    alpha_disc = (dist <= 0.98).astype(np.uint8) * 255
    disc = np.dstack([grad, alpha_disc])
    img = Image.fromarray(disc, "RGBA")

    # soft blue glow behind the portrait
    glow = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse((int(s * 0.20), int(s * 0.12), int(s * 0.80), int(s * 0.86)),
               fill=(55, 164, 255, 55))
    glow = glow.filter(ImageFilter.GaussianBlur(s // 8))
    img = Image.alpha_composite(img, glow)

    hh = int(s * 0.80)
    ratio = min(hh / head.width, hh / head.height)
    h = head.resize((int(head.width * ratio), int(head.height * ratio)), Image.LANCZOS)
    img.alpha_composite(h, ((s - h.width) // 2, (s - h.height) // 2 + int(s * 0.04)))

    d = ImageDraw.Draw(img)
    ring = max(2, s // 42)
    d.ellipse((2, 2, s - 3, s - 3), outline=(55, 164, 255, 255), width=ring)
    return img.resize((size, size), Image.LANCZOS)


for size in (256, 64, 32, 16):
    badge(size).save(f"assets/tray/icon_{size}.png")
badge(256).save("assets/tray/icon.png")
badge(32).save("assets/tray/tray.png")

# tray preview sheet
sheet = Image.new("RGB", (256 + 64 + 64 + 64 + 48, 300), (40, 44, 54))
x = 8
for size in (256, 64, 32, 16):
    icon = badge(size)
    p = Image.new("RGB", (size, size), (40, 44, 54))
    p.paste(icon, (0, 0), icon)
    sheet.paste(p, (x, 20))
    x += size + 16
sheet.save("tmp/tray_preview.png")
print("tray icons written")
