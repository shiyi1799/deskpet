const path = require('node:path');
const fs = require('node:fs');
const {
  app,
  BrowserWindow,
  Menu,
  Tray,
  ipcMain,
  nativeImage,
  screen,
} = require('electron');

const WIN_W = 220;
const WIN_H = 320;
const BOTTOM_MARGIN = 4;
const SNAP_DISTANCE = 56;

let mainWindow = null;
let tray = null;
let isQuitting = false;
let dragState = null;
let guardingSize = false;
let dockSide = null;

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.showInactive();
    }
  });
  app.whenReady().then(init);
}

function init() {
  app.setAppUserModelId('com.lacrimosa.oldmemory.pet');
  createWindow();
  createTray();
  screen.on('display-metrics-changed', keepOnScreen);
  screen.on('display-removed', keepOnScreen);
  app.on('before-quit', () => {
    isQuitting = true;
    persistPosition();
  });
  app.on('window-all-closed', () => {});
}

function createWindow() {
  const saved = readSettings();
  const start = Number.isFinite(saved.x) && Number.isFinite(saved.y)
    ? clampToWorkArea(saved.x, saved.y)
    : defaultPosition();

  mainWindow = new BrowserWindow({
    width: WIN_W,
    height: WIN_H,
    x: start.x,
    y: start.y,
    show: false,
    frame: false,
    transparent: true,
    backgroundColor: '#00000000',
    resizable: false,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    skipTaskbar: true,
    hasShadow: false,
    focusable: false,
    alwaysOnTop: true,
    title: '安魂曲 · 旧忆挽歌',
    icon: path.join(__dirname, '..', 'assets', 'tray', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      spellcheck: false,
      backgroundThrottling: false,
    },
  });

  mainWindow.setAlwaysOnTop(true, 'screen-saver');
  mainWindow.setMenuBarVisibility(false);
  mainWindow.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  mainWindow.webContents.on('will-navigate', (event) => event.preventDefault());

  mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));

  mainWindow.webContents.on('did-finish-load', () => {
    setDockSide(detectDockSide());
  });

  mainWindow.webContents.on('did-fail-load', (_event, code, description) => {
    console.error('PET_LOAD_FAILED', code, description);
  });

  mainWindow.once('ready-to-show', () => {
    mainWindow.showInactive();
    pinOnTop();
    setTimeout(pinOnTop, 400);
  });

  mainWindow.on('resize', () => {
    if (guardingSize || mainWindow.isDestroyed()) return;
    const bounds = mainWindow.getBounds();
    if (Math.abs(bounds.width - WIN_W) <= 24 && Math.abs(bounds.height - WIN_H) <= 24) {
      return;
    }
    console.warn('PET_WINDOW_RESIZE_GUARD', bounds);
    guardingSize = true;
    setPetBounds(bounds.x, bounds.y);
    guardingSize = false;
  });

  mainWindow.on('close', (event) => {
    if (!isQuitting) {
      event.preventDefault();
      mainWindow.hide();
    }
  });

  mainWindow.on('show', () => {
    mainWindow.setIgnoreMouseEvents(false);
    mainWindow.webContents.send('pet:paused', false);
    pinOnTop();
    refreshTrayMenu();
  });

  mainWindow.on('hide', () => {
    persistPosition();
    mainWindow.webContents.send('pet:paused', true);
    refreshTrayMenu();
  });
}

function settingsFile() {
  return path.join(app.getPath('userData'), 'settings.json');
}

function readSettings() {
  try {
    return JSON.parse(fs.readFileSync(settingsFile(), 'utf8'));
  } catch {
    return {};
  }
}

function persistPosition() {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  const bounds = mainWindow.getBounds();
  try {
    fs.mkdirSync(path.dirname(settingsFile()), { recursive: true });
    fs.writeFileSync(
      settingsFile(),
      JSON.stringify({ ...readSettings(), x: bounds.x, y: bounds.y }, null, 2),
      'utf8',
    );
  } catch (error) {
    console.error('Failed to save position:', error);
  }
}

function defaultPosition() {
  const wa = screen.getPrimaryDisplay().workArea;
  return {
    x: wa.x + wa.width - WIN_W - 36,
    y: wa.y + wa.height - WIN_H - BOTTOM_MARGIN,
  };
}

function clampToWorkArea(x, y) {
  const display = screen.getDisplayNearestPoint({
    x: Math.round(x + WIN_W / 2),
    y: Math.round(y + WIN_H / 2),
  });
  const wa = display.workArea;
  return {
    x: Math.min(Math.max(Math.round(x), wa.x), wa.x + Math.max(0, wa.width - WIN_W)),
    y: Math.min(Math.max(Math.round(y), wa.y), wa.y + Math.max(0, wa.height - WIN_H)),
  };
}

// setPosition alone drifts the window size at fractional display scales,
// so every move pins the intended size explicitly.
function setPetBounds(x, y) {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  mainWindow.setBounds({
    x: Math.round(x),
    y: Math.round(y),
    width: WIN_W,
    height: WIN_H,
  });
}

function keepOnScreen() {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  const [x, y] = mainWindow.getPosition();
  const pos = clampToWorkArea(x, y);
  setPetBounds(pos.x, pos.y);
  setDockSide(detectDockSide());
  persistPosition();
}

function workAreaFor(bounds) {
  return screen.getDisplayNearestPoint({
    x: bounds.x + Math.round(bounds.width / 2),
    y: bounds.y + Math.round(bounds.height / 2),
  }).workArea;
}

function setDockSide(side) {
  if (dockSide === side) return;
  dockSide = side;
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('pet:docked', side);
  }
}

function detectDockSide() {
  if (!mainWindow || mainWindow.isDestroyed()) return null;
  const bounds = mainWindow.getBounds();
  const wa = workAreaFor(bounds);
  if (Math.abs(bounds.x - wa.x) <= 2) return 'left';
  if (Math.abs(bounds.x + bounds.width - (wa.x + wa.width)) <= 2) return 'right';
  return null;
}

function snapToEdge(side) {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  const bounds = mainWindow.getBounds();
  const wa = workAreaFor(bounds);
  const x = side === 'left' ? wa.x : wa.x + wa.width - WIN_W;
  const y = Math.min(Math.max(bounds.y, wa.y), wa.y + Math.max(0, wa.height - WIN_H));
  setPetBounds(x, y);
  setDockSide(side);
  persistPosition();
  pinOnTop();
}

function snapToNearestEdge() {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  const bounds = mainWindow.getBounds();
  const wa = workAreaFor(bounds);
  const left = bounds.x - wa.x;
  const right = wa.x + wa.width - (bounds.x + bounds.width);

  if (left <= SNAP_DISTANCE && left <= right) {
    snapToEdge('left');
  } else if (right <= SNAP_DISTANCE) {
    snapToEdge('right');
  } else {
    setDockSide(null);
    persistPosition();
  }
}

function pinOnTop() {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  mainWindow.setAlwaysOnTop(true, 'screen-saver');
  if (mainWindow.isVisible()) {
    mainWindow.moveTop();
  }
}

function showPet() {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  mainWindow.showInactive();
  pinOnTop();
}

function recallPet() {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  const pos = defaultPosition();
  setPetBounds(pos.x, pos.y);
  setDockSide(null);
  mainWindow.showInactive();
  pinOnTop();
  mainWindow.webContents.send('pet:recall');
  persistPosition();
}

function toggleVisibility() {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  if (mainWindow.isVisible()) {
    mainWindow.hide();
  } else {
    showPet();
  }
}

function createTray() {
  const iconPath = path.join(__dirname, '..', 'assets', 'tray', 'tray.png');
  const icon = nativeImage.createFromPath(iconPath);
  tray = new Tray(icon.resize({ width: 16, height: 16 }));
  tray.setToolTip('安魂曲 · 旧忆挽歌');
  tray.on('click', toggleVisibility);
  refreshTrayMenu();
}

function refreshTrayMenu() {
  if (!tray) return;
  const visible = Boolean(mainWindow && mainWindow.isVisible());
  const menu = Menu.buildFromTemplate([
    {
      label: visible ? '隐藏桌宠' : '显示桌宠',
      click: toggleVisibility,
    },
    {
      label: '召回桌宠',
      click: recallPet,
    },
    {
      label: '贴靠左侧',
      click: () => snapToEdge('left'),
    },
    {
      label: '贴靠右侧',
      click: () => snapToEdge('right'),
    },
    { type: 'separator' },
    {
      label: '开机自启',
      type: 'checkbox',
      checked: isAutoStartEnabled(),
      click: (item) => setAutoStart(item.checked),
    },
    { type: 'separator' },
    {
      label: '退出',
      click: () => {
        isQuitting = true;
        app.quit();
      },
    },
  ]);
  tray.setContextMenu(menu);
}

function autoStartOptions() {
  return {
    path: process.execPath,
    args: app.isPackaged ? [] : [app.getAppPath()],
  };
}

function isAutoStartEnabled() {
  try {
    return app.getLoginItemSettings(autoStartOptions()).openAtLogin;
  } catch {
    return false;
  }
}

function setAutoStart(enabled) {
  try {
    app.setLoginItemSettings({ openAtLogin: enabled, ...autoStartOptions() });
  } catch (error) {
    console.error('Failed to update auto-start:', error);
  }
  refreshTrayMenu();
}

ipcMain.on('pet:drag-start', (event) => {
  if (!mainWindow || event.sender !== mainWindow.webContents) return;
  const cursor = screen.getCursorScreenPoint();
  const [x, y] = mainWindow.getPosition();
  dragState = {
    cursorX: cursor.x,
    cursorY: cursor.y,
    windowX: x,
    windowY: y,
  };
});

ipcMain.on('pet:drag-move', (event) => {
  if (!mainWindow || event.sender !== mainWindow.webContents || !dragState) return;
  const cursor = screen.getCursorScreenPoint();
  const pos = clampToWorkArea(
    dragState.windowX + (cursor.x - dragState.cursorX),
    dragState.windowY + (cursor.y - dragState.cursorY),
  );
  setPetBounds(pos.x, pos.y);
});

ipcMain.on('pet:drag-end', (event) => {
  if (!mainWindow || event.sender !== mainWindow.webContents) return;
  dragState = null;
  snapToNearestEdge();
});

ipcMain.on('pet:set-ignore-mouse', (event, ignore) => {
  if (!mainWindow || event.sender !== mainWindow.webContents) return;
  if (ignore) {
    mainWindow.setIgnoreMouseEvents(true, { forward: true });
  } else {
    mainWindow.setIgnoreMouseEvents(false);
  }
});
