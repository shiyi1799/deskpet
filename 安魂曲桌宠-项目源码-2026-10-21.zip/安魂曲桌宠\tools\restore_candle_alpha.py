import numpy as np
from PIL import Image
from scipy import ndimage

HIRES = "assets/pet/pet_hires.png"
SMALL = "assets/pet/pet.png"
SMALL_SIZE = (194, 375)


def restore(alpha, rgb, box, vmin=0.5, smax=0.5, minsize=20, sigma=0.8):
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    mx, mn = rgb.max(2), rgb.min(2)
    v = mx / 255.0
    s = (mx - mn) / np.maximum(mx, 1)
    x0, y0, x1, y1 = box
    roi = np.zeros(alpha.shape, bool)
    roi[y0:y1, x0:x1] = True
    cand = roi & (v > vmin) & (s < smax) & ((r - b) > -40)
    labels, n = ndimage.label(cand)
    keep = np.zeros_like(cand)
    for i in range(1, n + 1):
        comp = labels == i
        if comp.sum() >= minsize:
            keep |= comp
    keep = ndimage.binary_fill_holes(ndimage.binary_closing(keep, np.ones((3, 3))))
    soft = ndimage.gaussian_filter(keep.astype(np.float32), sigma) * 255
    return np.maximum(alpha, soft)


def main():
    img = Image.open(HIRES).convert("RGBA")
    raw = np.array(img).astype(np.float32)
    rgb, alpha = raw[..., :3], raw[..., 3]

    # The largest-component alpha cleanup also dropped the right-hand candle
    # and the tall candle's flame; their RGB survived in the cutout.
    alpha = restore(alpha, rgb, (436, 240, 468, 331))
    alpha = restore(alpha, rgb, (410, 198, 428, 228), smax=0.55, minsize=15, sigma=0.7)

    out = Image.fromarray(np.dstack([rgb.astype(np.uint8), alpha.astype(np.uint8)]), "RGBA")
    out.save(HIRES)
    out.resize(SMALL_SIZE, Image.LANCZOS).save(SMALL)
    print("restored alpha and rewrote", HIRES, SMALL)


if __name__ == "__main__":
    main()
